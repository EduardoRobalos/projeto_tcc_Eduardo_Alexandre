function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

document.addEventListener('DOMContentLoaded', () => {
    verificarModoVisitante();
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    if (displayElement) {
        displayElement.innerText = (!isVisitante && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    const initialsElement = document.getElementById('avatarInitials');
    if (initialsElement) {
        if (isVisitante || !nomeCompleto) {
 
            initialsElement.innerHTML = '<i class="fas fa-user"></i>';
   
        } else {

            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }

});

function getUserInitials(fullName) {
    if (!fullName) return '--';

    const partes = fullName.trim().split(/\s+/); 

    if (partes.length === 0) return '--';

    const primeira = partes[0][0]; 
 
    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';

    return (primeira + ultima).toUpperCase();
}

function verificarAcessoHistorico() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_usuario');

    if (isVisitante || isNaoLogado) {
 
        showToast(" Acesso Restrito\n\nO Histórico de Consultas está disponível apenas para usuários cadastrados.\nFaça login para salvar e consultar suas avaliações.", 'error');

    } else {

        window.location.href = 'historico.html';
    }
}

function openTab(evt, tabName) {

    const tabContents = document.getElementsByClassName("tab-content");
    for (let i = 0; i < tabContents.length; i++) {
        tabContents[i].classList.remove("active");
    }

    const tabButtons = document.getElementsByClassName("tab-btn");
    for (let i = 0; i < tabButtons.length; i++) {
        tabButtons[i].classList.remove("active");
    }

    document.getElementById(tabName).classList.add("active");
    evt.currentTarget.classList.add("active");
}

function toggleSequence(modo) {

    document.getElementById('vestir').style.display = 'none';
    document.getElementById('retirar').style.display = 'none';

    document.getElementById('vestir').classList.remove('active');
    document.getElementById('retirar').classList.remove('active');

    const selecionado = document.getElementById(modo);
    selecionado.style.display = 'flex';

    setTimeout(() => selecionado.classList.add('active'), 10);

    const botoes = document.querySelectorAll('.seq-btn');
    botoes.forEach(btn => btn.classList.remove('active'));

    if (modo === 'vestir') botoes[0].classList.add('active');
    else botoes[1].classList.add('active');
}

function verificarModoVisitante() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    const authButtons = document.querySelector('.auth-buttons');
    const profileIcon = document.querySelector('.profile-icon');

    if (displayElement) {
        if (isVisitante) {
            displayElement.innerText = "Visitante";
        } else {
            const nome = localStorage.getItem('nome_completo');
            displayElement.innerText = nome ? nome.split(' ')[0] : "Usuário";
        }
    }

    if (authButtons) {
        authButtons.style.display = isVisitante ? 'flex' : 'none';
    }

    if (profileIcon && isVisitante) {
        profileIcon.style.color = "#888";
        profileIcon.style.opacity = "0.7";
 
        profileIcon.onclick = null;
        profileIcon.addEventListener('click', (e) => {
            e.preventDefault(); 
            showToast("Modo Visitante: Faça login para ver seu perfil.", "error");
        });
    }
}