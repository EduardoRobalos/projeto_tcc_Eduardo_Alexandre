function showToast(message, type = 'success') {

    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out'); 
        toast.addEventListener('animationend', () => {
            toast.remove(); 
        });
    }, 4000);
}

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const usernameInput = document.getElementById('username').value;
    const passwordInput = document.getElementById('password').value;

    const dataPayload = {
        username: usernameInput,
        password: passwordInput
    };

    try {
        const response = await fetch('http://localhost:3000/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(dataPayload)
        });

        const result = await response.json();


        if (response.ok) {
            const userData = result.userData || {};

            localStorage.setItem('nome_usuario', userData.nome_usuario || usernameInput);
            localStorage.setItem('nome_completo', userData.nome || '');

            localStorage.setItem('adm', userData.adm ? 'true' : 'false');

            localStorage.removeItem('modo_visitante');

            window.location.href = 'pgPrincipal.html';
            return;
        }


        showToast(result.message, 'error');

    } catch (error) {
        showToast("Erro ao conectar com o servidor.", 'error');
    }
});