function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

(function () {
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_usuario');

    if (isVisitante || isNaoLogado) {
        showToast("Você precisa estar logado para acessar esta página.", 'error');
        window.location.href = 'pgPrincipal.html'; 
        throw new Error("Acesso negado: Visitante."); 
    }
})();

document.addEventListener('DOMContentLoaded', () => {
 
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    if (displayElement) {
        displayElement.innerText = (!isVisitante && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    const initialsElement = document.getElementById('avatarInitials');
    if (initialsElement) {
        if (isVisitante || !nomeCompleto) {
 
            initialsElement.innerHTML = '<i class="fas fa-user"></i>';
  
        } else {

            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }
});

function getUserInitials(fullName) {
    if (!fullName) return '--';

    const partes = fullName.trim().split(/\s+/); 

    if (partes.length === 0) return '--';

    const primeira = partes[0][0];
 
    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';

    return (primeira + ultima).toUpperCase();
}

let todosOsLogs = [];

document.addEventListener('DOMContentLoaded', () => {
    carregarDadosBase();
    configurarFiltros();

    const btnLimpar = document.getElementById('btnLimpar');
    if (btnLimpar) btnLimpar.addEventListener('click', limparHistorico);
});

const urlParams = new URLSearchParams(window.location.search);
const isAnonymous = urlParams.get('mode') === 'anonymous';
const profileIcon = document.querySelector('.profile-icon');

if (isAnonymous) {
    showtoast("O histórico não está disponível no Modo Visitante. Por favor, faça login.", 'error');
    window.location.href = 'pgPrincipal.html?mode=anonymous';

    profileIcon.style.color = "#888";
    profileIcon.style.opacity = "0.7";

    profileIcon.addEventListener('click', () => {
        showtoast("Modo Visitante: Crie uma conta ou faça login para aceder às configurações de perfil e histórico.", 'error');
    });
} else {

    profileIcon.addEventListener('click', () => {
        window.location.href = 'perfil.html';
    });
}

const authButtons = document.querySelector('.auth-buttons');

if (isAnonymous) {
    authButtons.style.display = 'flex';
} else {
    authButtons.style.display = 'none';
}

function carregarDadosBase() {
    todosOsLogs = JSON.parse(localStorage.getItem('meu_historico_consultas')) || [];

    atualizarContadoresFiltro();

    renderizarLista(todosOsLogs);
}

function configurarFiltros() {
    const botoes = document.querySelectorAll('.filter-btn');

    botoes.forEach(btn => {
        btn.addEventListener('click', () => {

            botoes.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');

            const categoria = btn.innerText.split('(')[0].trim();
            aplicarFiltro(categoria);
        });
    });
}

function aplicarFiltro(categoria) {
    let logsFiltrados = [];

    if (categoria === "Todos") {
        logsFiltrados = todosOsLogs;
    } else if (categoria === "Perigosos") {

        logsFiltrados = todosOsLogs.filter(log => log.risco_score >= 8);
    } else if (categoria === "Moderado") {

        logsFiltrados = todosOsLogs.filter(log => log.risco_score >= 5 && log.risco_score < 8);
    } else if (categoria === "Baixo Risco") {

        logsFiltrados = todosOsLogs.filter(log => log.risco_score < 5);
    }

    renderizarLista(logsFiltrados);
}

function atualizarContadoresFiltro() {
    const counts = {
        todos: todosOsLogs.length,
        perigosos: todosOsLogs.filter(l => l.risco_score >= 8).length,
        moderado: todosOsLogs.filter(l => l.risco_score >= 5 && l.risco_score < 8).length,
        baixo: todosOsLogs.filter(l => l.risco_score < 5).length
    };

    const botoes = document.querySelectorAll('.filter-btn');
    botoes[0].innerText = `Todos(${counts.todos})`;
    botoes[1].innerText = `Perigosos(${counts.perigosos})`;
    botoes[2].innerText = `Moderado(${counts.moderado})`;
    botoes[3].innerText = `Baixo Risco(${counts.baixo})`;

    document.getElementById('totalConsultas').innerText = `${counts.todos} Consulta(s) realizada(s)`;
}

function renderizarLista(logs) {
    const listaEl = document.getElementById('lista-historico');
    listaEl.innerHTML = '';

    if (logs.length === 0) {
        listaEl.innerHTML = '<p style="text-align:center; padding:20px; color:#888;">Nenhum item encontrado.</p>';
        return;
    }

    logs.forEach(log => {
        let riskLevelClass = log.risco_score >= 8 ? 'risk-red' : (log.risco_score >= 5 ? 'risk-yellow' : 'risk-green');

        const logString = JSON.stringify(log.dados_completos).replace(/"/g, '&quot;');

        listaEl.innerHTML += `
            <div class="history-card ${riskLevelClass}" 
                 onclick="verNovamente('${logString}')" 
                 style="cursor: pointer;" 
                 title="Clique para ver a avaliação completa">
                <div style="display:flex; align-items:center;">
                    <div class="score-circle">${log.risco_score}</div>
                    <div class="card-content">
                        <h3>${log.residuo_nome}</h3>
                        <small>${log.classe || 'Classe não informada'}</small>
                    </div>
                </div>
                <div class="card-score-right">
                    <span class="score-label">Risco</span>
                    <span class="score-big">${log.risco_score}/10</span>
                </div>
            </div>
        `;
    });
}

function verNovamente(dadosString) {
    const dados = JSON.parse(dadosString);

    localStorage.setItem('ultimo_residuo_visualizado', JSON.stringify(dados));

    window.location.href = 'pgPrincipal.html' + window.location.search;
}

function limparHistorico() {
    if (confirm("Deseja apagar todo o histórico?")) {
        localStorage.removeItem('meu_historico_consultas');
        todosOsLogs = [];
        atualizarContadoresFiltro();
        renderizarLista([]);
    }
}
