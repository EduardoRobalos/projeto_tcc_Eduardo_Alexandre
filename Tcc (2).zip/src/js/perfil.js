function showToast(message, type = 'success') {

  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const isSuccess = type === 'success';
  const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
  const title = isSuccess ? 'Sucesso!' : 'Atenção';
  const cssClass = isSuccess ? 'toast-success' : 'toast-error';

  const toast = document.createElement('div');
  toast.className = `eco-toast ${cssClass}`;
  toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

  container.appendChild(toast);

  setTimeout(() => {
    toast.classList.add('toast-out'); 
    toast.addEventListener('animationend', () => {
      toast.remove(); 
    });
  }, 4000);
}

document.getElementById('btnVoltar').addEventListener('click', () => {
  if (document.referrer && document.referrer.indexOf(window.location.hostname) !== -1) {
    history.back();
  } else {
    window.location.href = 'pgPrincipal.html';
  }
});

const API_BASE_URL = 'http://localhost:3000';

const state = {
  email: '',
  nomeUsuario: ''
};

const $ = (id) => document.getElementById(id);
const has = (id) => Boolean($(id));

function setText(id, value) {
  const el = $(id);
  if (el) el.innerText = value ?? '';
}


function setValue(id, value) {
  const el = $(id);
  if (el) el.value = value;
}

function setDisabled(id, disabled = true) {
  const el = $(id);
  if (!el) return;
  if (disabled) el.setAttribute('disabled', true);
  else el.removeAttribute('disabled');
}

function togglePass(inputId, button) {
  const input = $(inputId);
  const icon = button?.querySelector('i');

  if (!input || !icon) return;

  const isPassword = input.type === 'password';
  input.type = isPassword ? 'text' : 'password';
  icon.classList.toggle('fa-eye-slash', !isPassword);
  icon.classList.toggle('fa-eye', isPassword);
}

function logout() {
  localStorage.removeItem("userName");
  localStorage.removeItem('email');
  localStorage.removeItem('ultimo_residuo_visualizado');
  window.location.href = 'login.html';
}

function setGuestMode() {
  setText('displayName', 'Visitante');
  setText('memberType', 'Entre para editar seu perfil');
  setValue('username', 'Faça login para acessar');
  setValue('email', 'Não autenticado');

  ['username', 'email', 'btnShowPassword', 'btnEditUsername', 'btnSave', 'btnLogout']
    .forEach((id) => setDisabled(id, true));

  $('passwordSection')?.classList.add('hidden');
  $('guestNotice')?.classList.remove('hidden');
}

function editUsername() {
  const usernameInput = $('username');

  if (!usernameInput || usernameInput.disabled) return;

  usernameInput.removeAttribute('readonly');
  usernameInput.focus();
  usernameInput.select();
}

async function carregarPerfil() {
  const nomeUsuario = localStorage.getItem('nome_usuario') || localStorage.getItem('userName');
  if (!nomeUsuario) {
    setText('sidebarName', 'Visitante');
    setText('avatarInitials', '--');
    return;
  }

  try {
    const response = await fetch(`${API_BASE_URL}/get-user-profile/${encodeURIComponent(nomeUsuario)}`);

    if (!response.ok) throw new Error();

    const user = await response.json();

    state.email = user.email;
    state.nomeUsuario = user.nome_usuario;

    const nomeCompleto = user.nome_completo || 'Usuário';
    localStorage.setItem('nome_completo', nomeCompleto);
    localStorage.setItem('nome_usuario', user.nome_usuario || nomeUsuario || '');
    setText('sidebarName', nomeCompleto);
    setText('displayUsername', user.nome_usuario || '-');
    setText('displayEmail', user.email || '-');
    setText('avatarInitials', getUserInitials(nomeCompleto));

  } catch (error) {
    console.error(error);
    setText('sidebarName', 'Erro ao carregar');
    setText('avatarInitials', '--');
  }
}

function initEvents() {
  if (!has('profileForm')) return;

  $('btnVoltar')?.addEventListener('click', () => {
    if (document.referrer && document.referrer.includes(window.location.hostname)) {
      history.back();
      return;
    }
    window.location.href = 'pgPrincipal.html';
  });

  $('btnEditUsername')?.addEventListener('click', editUsername);

  $('btnShowPassword')?.addEventListener('click', () => {
    const section = $('passwordSection');
    if (!section) return;

    section.classList.toggle('hidden');
    if (!section.classList.contains('hidden')) {
      section.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });

  $('btnGoLogin')?.addEventListener('click', () => {
    window.location.href = 'login.html';
  });

  $('btnLogout')?.addEventListener('click', logout);
  $('profileForm')?.addEventListener('submit', salvarAlteracoes);

  document.querySelectorAll('[data-toggle-pass]').forEach((button) => {
    button.addEventListener('click', () => togglePass(button.dataset.togglePass, button));
  });
}

document.addEventListener('DOMContentLoaded', () => {
  initEvents();
  carregarPerfil();
});

function enableEdit(type) {
  if (type === 'name') {
    $('edit-name-form').style.display = 'block';
    $('inputName').value = state.nomeUsuario || '';
    $('inputName').focus();
  }

  if (type === 'email') {
    $('edit-email-form').style.display = 'block';
    $('inputEmail').value = state.email || '';
    $('inputEmail').focus();
  }
}

function cancelEdit(type) {
  if (type === 'name') $('edit-name-form').style.display = 'none';
  if (type === 'email') $('edit-email-form').style.display = 'none';
}

async function submitUsernameEdit(e) {
  e.preventDefault();

  const novoNome = $('inputName').value.trim();
  if (!novoNome) return showToast('Digite um nome de usuário.', 'error');

  if (novoNome === state.nomeUsuario) {
    cancelEdit('name');
    return;
  }

  const check = await fetch(`${API_BASE_URL}/check-username?nome=${encodeURIComponent(novoNome)}`);
  const data = await check.json();

  if (data.exists) return showToast('Esse nome de usuário já está em uso.', 'error'); 

  const resp = await fetch(`${API_BASE_URL}/update-username`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: state.email, username: novoNome })
  });

  const result = await resp.json();
  if (!resp.ok) return showToast(result.message || 'Erro ao atualizar.', 'error'); 


  state.nomeUsuario = novoNome;
  localStorage.setItem('userName', novoNome);
  localStorage.setItem('nome_usuario', novoNome);

  setText('displayUsername', novoNome);
  cancelEdit('name');

  showToast('Nome de usuário atualizado com sucesso!', 'success'); 
}

async function submitEmailEdit(e) {
  e.preventDefault();

  const novoEmail = $('inputEmail').value.trim();
  if (!novoEmail) return alert('Digite um e-mail.');

  if (novoEmail === state.email) {
    cancelEdit('email');
    return;
  }

  const check = await fetch(`${API_BASE_URL}/check-email?email=${encodeURIComponent(novoEmail)}`);
  const data = await check.json();

  if (data.exists) return alert('Esse e-mail já está em uso.');

  const resp = await fetch(`${API_BASE_URL}/update-email`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ oldEmail: state.email, newEmail: novoEmail })
  });

  const result = await resp.json();
  if (!resp.ok) return alert(result.message || 'Erro ao atualizar e-mail.');

  state.email = novoEmail;
  localStorage.setItem('email', novoEmail);

  setText('displayEmail', (novoEmail));
  cancelEdit('email');

  showToast('E-mail atualizado com sucesso!', 'success');
}

document.addEventListener('DOMContentLoaded', () => {
  carregarPerfil();

  $('edit-name-form')?.addEventListener('submit', submitUsernameEdit);
  $('edit-email-form')?.addEventListener('submit', submitEmailEdit);
});

function togglePasswordSection() {
  const form = document.getElementById("passwordForm");
  if (!form) return;

  const isHidden = form.style.display === "none" || !form.style.display;
  form.style.display = isHidden ? "block" : "none";
}

async function handleChangePassword(e) {
  e.preventDefault();

  const oldPass = document.getElementById("oldPass")?.value.trim() || "";
  const newPass = document.getElementById("newPass")?.value.trim() || "";
  const confirmPass = document.getElementById("confirmPass")?.value.trim() || "";

  if (!oldPass || !newPass || !confirmPass) {
    return alert("Preencha todos os campos.");
  }
  if (newPass.length < 6) {
    return alert("A nova senha deve ter pelo menos 6 caracteres.");
  }
  if (newPass !== confirmPass) {
    return alert("As senhas não coincidem.");
  }

  const resp = await fetch(`${API_BASE_URL}/change-password`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      nome_usuario: state.nomeUsuario,
      oldPassword: oldPass,
      newPassword: newPass
    }),
  });

  const data = await resp.json().catch(() => ({}));
  if (!resp.ok) return alert(data.message || "Não foi possível alterar a senha.");

  document.getElementById("oldPass").value = "";
  document.getElementById("newPass").value = "";
  document.getElementById("confirmPass").value = "";
  togglePasswordSection();

  showToast("Senha atualizada com sucesso!", 'success');
}

document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("passwordForm")?.addEventListener("submit", handleChangePassword);
});

const newPassInput = document.getElementById("newPass");
const confirmPassInput = document.getElementById("confirmPass");

const newPassError = document.getElementById("newPassError");
const confirmPassError = document.getElementById("confirmPassError");

function showError(input, errorEl, message) {
  input.classList.add("input-error");
  errorEl.innerText = message;
}

function clearError(input, errorEl) {
  input.classList.remove("input-error");
  errorEl.innerText = "";
}

function validateNewPassword() {
  const value = newPassInput.value.trim();

  if (value.length === 0) {
    clearError(newPassInput, newPassError);
    return false;
  }

  if (value.length < 6) {
    showError(newPassInput, newPassError, "Mínimo de 6 caracteres");
    return false;
  }

  clearError(newPassInput, newPassError);
  return true;
}

function validateConfirmPassword() {
  const newValue = newPassInput.value.trim();
  const confirmValue = confirmPassInput.value.trim();

  if (confirmValue.length === 0) {
    clearError(confirmPassInput, confirmPassError);
    return false;
  }

  if (newValue !== confirmValue) {
    showError(confirmPassInput, confirmPassError, "As senha não coincidem");
    return false;
  }

  clearError(confirmPassInput, confirmPassError);
  return true;
}

newPassInput?.addEventListener("input", () => {
  validateNewPassword();
  validateConfirmPassword();
});

confirmPassInput?.addEventListener("input", validateConfirmPassword);

function getUserInitials(fullName = '') {
  const partes = fullName.trim().split(/\s+/).filter(Boolean);
  if (partes.length === 0) return '--';

  const primeira = partes[0][0] || '';
  const ultima = (partes.length > 1 ? partes[partes.length - 1][0] : partes[0][1] || partes[0][0]) || '';
  return `${primeira}${ultima}`.toUpperCase();
}