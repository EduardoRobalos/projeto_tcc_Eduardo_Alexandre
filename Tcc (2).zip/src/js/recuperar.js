function showToast(message, type = 'success') {

    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out'); 
        toast.addEventListener('animationend', () => {
            toast.remove(); 
        });
    }, 4000);
}

document.getElementById('recoveryForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;

    try {

        const response = await fetch('http://localhost:3000/recuperar-senha', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: email })
        });

        const result = await response.json();

        if (response.ok) {
            showToast(result.message, 'success');
 
            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2500);
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error("Erro na requisição:", error);
        showToast("Não foi possível conectar ao servidor.", 'error');
    }
});