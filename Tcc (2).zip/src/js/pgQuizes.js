const perguntas = [
    {
        pergunta: "Qual é o EPI OBRIGATÓRIO para manusear soda cáustica?",
        opcoes: [
            "Apenas luvas de procedimento",
            "Protetor facial completo, luvas nítricas e avental de PVC",
            "Máscara cirúrgica e luvas",
            "Óculos de grau e luvas"
        ],
        correta: 1,
        topico: "Uso de EPIs"
    },
    {
        pergunta: "Ao diluir um ácido, o procedimento correto é:",
        opcoes: [
            "Colocar água no ácido",
            "Adicionar o ácido na água lentamente",
            "Misturar tudo rapidamente",
            "Aquecer o recipiente"
        ],
        correta: 1,
        topico: "Manuseio Seguro"
    },
    {
        pergunta: "Qual símbolo indica substância inflamável?",
        opcoes: ["Caveira", "Chama", "Exclamação", "Cruz"],
        correta: 1,
        topico: "Símbolos de Perigo"
    },
    {
        pergunta: "Em caso de derramamento químico, o primeiro passo é:",
        opcoes: [
            "Limpar imediatamente com pano",
            "Evacuar e notificar supervisor",
            "Diluir com água",
            "Ignorar se pequeno"
        ],
        correta: 1,
        topico: "Protocolos de Emergência"
    },
    {
        pergunta: "Ácidos e bases devem ser armazenados:",
        opcoes: [
            "Juntos no mesmo armário",
            "Separados para evitar reações",
            "Em prateleiras altas sem separação",
            "No chão para acesso rápido"
        ],
        correta: 1,
        topico: "Armazenamento de Químicos"
    },
    {
        pergunta: "Por que luvas nítricas são indicadas para solventes orgânicos?",
        opcoes: [
            "São mais baratas",
            "Resistem melhor a perfuração e químicos",
            "São mais confortáveis",
            "São recicláveis"
        ],
        correta: 1,
        topico: "Uso de EPIs"
    },
    {
        pergunta: "Qual é o risco de misturar amônia com hipoclorito (água sanitária)?",
        opcoes: [
            "Nada acontece",
            "Liberação de gás cloro tóxico",
            "Explosão",
            "Fogo"
        ],
        correta: 1,
        topico: "Manuseio Seguro"
    },
    {
        pergunta: "O símbolo de corrosão significa que o produto:",
        opcoes: [
            "É inflamável",
            "Corroi pele ou metais",
            "É tóxico por ingestão",
            "É radioativo"
        ],
        correta: 1,
        topico: "Símbolos de Perigo"
    },
    {
        pergunta: "Qual EPI protege os olhos contra respingos químicos fortes?",
        opcoes: [
            "Óculos de grau",
            "Óculos de segurança com proteção lateral",
            "Máscara de solda",
            "Protetor auricular"
        ],
        correta: 1,
        topico: "Uso de EPIs"
    },
    {
        pergunta: "A ficha de segurança (FISPQ) é usada principalmente para:",
        opcoes: [
            "Saber o preço do produto",
            "Conhecer riscos, manuseio e armazenamento correto",
            "Ver a cor do produto",
            "Saber o fabricante"
        ],
        correta: 1,
        topico: "Armazenamento de Químicos"
    }
];

let indiceAtual = 0;
let pontos = 0;
let errosPorTopico = [];

const elPontos = document.getElementById("pontos");
const elBarra = document.getElementById("barra");
const elTextoProgresso = document.getElementById("texto-progresso");
const elPergunta = document.getElementById("pergunta-texto");
const elOpcoes = document.getElementById("opcoes");
const elBtnProxima = document.getElementById("btn-proxima");
const elAreaPergunta = document.getElementById("area-pergunta");
const elResultado = document.getElementById("resultado");
const elTituloResultado = document.getElementById("resultado-titulo-texto");
const elPorcentagem = document.getElementById("resultado-porcentagem");
const elMensagem = document.getElementById("resultado-mensagem");
const elRecomendacoes = document.getElementById("recomendacoes");
const elListaRecom = document.getElementById("recomendacoes-lista");

function mostrarPergunta() {
    const p = perguntas[indiceAtual];
    const elTopico = document.getElementById("topico-atual");
    if (elTopico) elTopico.textContent = p.topico;

    elPergunta.textContent = p.pergunta;
    elOpcoes.innerHTML = "";

    elPontos.textContent = `Pontos: ${pontos}/${perguntas.length}`;
    elTextoProgresso.textContent = `Pergunta ${indiceAtual + 1} de ${perguntas.length}`;
    const progressoAtual = ((indiceAtual + 1) / perguntas.length) * 100;
    elBarra.style.width = progressoAtual + "%";

    p.opcoes.forEach((texto, i) => {
        const btn = document.createElement("button");
        btn.textContent = texto;
        btn.onclick = () => {
            elOpcoes.querySelectorAll("button").forEach(b => b.disabled = true);
            if (i === p.correta) {
                btn.classList.add("correto");
                pontos++;
            } else {
                btn.classList.add("errado");
                elOpcoes.children[p.correta].classList.add("correto");
                errosPorTopico.push(p.topico);
            }
            elBtnProxima.disabled = false;
        };
        elOpcoes.appendChild(btn);
    });

    elBtnProxima.disabled = true;
}

document.addEventListener('DOMContentLoaded', () => {
    verificarModoVisitante();
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    if (displayElement) {
        displayElement.innerText = (!isVisitante && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    const initialsElement = document.getElementById('avatarInitials');
    if (initialsElement) {
        if (isVisitante || !nomeCompleto) {

            initialsElement.innerHTML = '<i class="fas fa-user"></i>';

        } else {

            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }

});

elBtnProxima.onclick = () => {
    indiceAtual++;
    if (indiceAtual < perguntas.length) {
        mostrarPergunta();
    } else {
        mostrarResultado();
    }
};

function mostrarResultado() {

    elAreaPergunta.style.display = "none";
    elBtnProxima.style.display = "none";
    const areaReiniciar = document.querySelector('.reiniciar-area');
    if (areaReiniciar) areaReiniciar.style.display = "none";

    const totalPerguntas = perguntas.length;
    const aproveitamento = Math.round((pontos / totalPerguntas) * 100);


    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    let nomeUsuario = "Visitante";
    if (!isVisitante && localStorage.getItem('nome_completo')) {
        nomeUsuario = localStorage.getItem('nome_completo').split(' ')[0];
    }

    elResultado.classList.remove("hidden");

    if (elTituloResultado) {
        elTituloResultado.textContent = aproveitamento >= 70
            ? `Excelente gestão, ${nomeUsuario}!`
            : `Boa gestão, mas com melhorias, ${nomeUsuario}!`;
    }

    if (elPorcentagem) {
        elPorcentagem.textContent = `${aproveitamento}%`;
    }

    if (elListaRecom) {
        elListaRecom.innerHTML = "";

        const topicosUnicos = [...new Set(errosPorTopico)];

        if (topicosUnicos.length === 0) {
            elListaRecom.innerHTML = `<li><i class="fas fa-check-circle" style="color: #2ecc71;"></i> Parabéns! Você domina todos os protocolos.</li>`;
        } else {
            topicosUnicos.forEach(topico => {
                const li = document.createElement("li");
                li.innerHTML = `<i class="fas fa-exclamation-triangle"></i> Revisar conteúdo de: <strong>${topico}</strong>`;
                elListaRecom.appendChild(li);
            });
        }
    }

    if (elMensagem) {
        elMensagem.textContent = aproveitamento >= 70
            ? "Você está seguindo todos os protocolos de segurança química corretamente!"
            : "Atenção aos pontos destacados abaixo para garantir a segurança no laboratório.";
    }
}

function reiniciar() {
    indiceAtual = 0;
    pontos = 0;
    errosPorTopico = [];


    elAreaPergunta.style.display = "block";
    elBtnProxima.style.display = "block";
    const areaReiniciar = document.querySelector('.reiniciar-area');
    if (areaReiniciar) areaReiniciar.style.display = "flex";

    elResultado.classList.add("hidden");

    mostrarPergunta();
}

document.getElementById("btn-reiniciar").onclick = reiniciar;
document.getElementById("jogar-novamente").onclick = reiniciar;

function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

function getUserInitials(fullName) {
    if (!fullName) return '--';
    const partes = fullName.trim().split(/\s+/);
    if (partes.length === 0) return '--';

    const primeira = partes[0][0];
    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';

    return (primeira + ultima).toUpperCase();
}

function atualizarPerfil() {
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isNaoLogado = !localStorage.getItem('email') && !nomeCompleto;
    const isAnonymous = isVisitante || isNaoLogado;

    const elNome = document.getElementById('userNameDisplay');
    const elAvatar = document.getElementById('avatarInitials');
    const profileIcon = document.getElementById('profileIconContainer');

    if (elNome) {
        elNome.innerText = isAnonymous ? 'Visitante' : (nomeCompleto || 'Usuário');
    }

    if (elAvatar) {
        if (isAnonymous) {
            elAvatar.innerHTML = '<i class="fas fa-user"></i>';
        } else {
            elAvatar.innerText = getUserInitials(nomeCompleto);
        }
    }
}

function verificarAcessoHistorico() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_completo');

    if (isVisitante || isNaoLogado) {

        showToast("Acesso Restrito: O Histórico está disponível apenas para usuários cadastrados. Faça login para consultar suas avaliações.", 'error');
    } else {

        window.location.href = 'historico.html' + window.location.search;
    }
}

function verificarModoVisitante() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    const authButtons = document.querySelector('.auth-buttons');
    const profileIcon = document.querySelector('.profile-icon');

    if (displayElement) {
        if (isVisitante) {
            displayElement.innerText = "Visitante";
        } else {
            const nome = localStorage.getItem('nome_completo');
            displayElement.innerText = nome ? nome.split(' ')[0] : "Usuário";
        }
    }

    if (authButtons) {
        authButtons.style.display = isVisitante ? 'flex' : 'none';
    }

    if (profileIcon && isVisitante) {
        profileIcon.style.color = "#888";
        profileIcon.style.opacity = "0.7";

        profileIcon.onclick = null;
        profileIcon.addEventListener('click', (e) => {
            e.preventDefault();
            showToast("Modo Visitante: Faça login para ver seu perfil.", "error");
        });
    }
}

window.addEventListener('DOMContentLoaded', () => {
    atualizarPerfil();
    mostrarPergunta();

});
