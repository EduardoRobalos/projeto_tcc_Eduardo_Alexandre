const videosData = [
    {
        id: 1,
        titulo: "Como usar EPIs corretamente em Laboratório",
        categoria: "EPIs",
        url: "https://youtube.com/embed/1aks7R6QXV0"
    },
    {
        id: 2,
        titulo: "Descarte correto de Ácido Sulfúrico",
        categoria: "Manuseio",
        url: "https://youtube.com/embed/8YRl79CcVBo"
    },
];

function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

const grid = document.getElementById('videoGrid');
const searchInput = document.getElementById('videoSearch');
const btnFilter = document.getElementById('btnFilter');
const filterDropdown = document.getElementById('filterDropdown');
const filterOptions = document.querySelectorAll('.filter-option');
const historicoConsultas = JSON.parse(localStorage.getItem('meu_historico_consultas')) || [];
const profileIcon = document.querySelector('.profile-icon');
const urlParams = new URLSearchParams(window.location.search);
const isAnonymous = urlParams.get('mode') === 'anonymous';


function verificarModoVisitante() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    const authButtons = document.querySelector('.auth-buttons');
    const profileIcon = document.querySelector('.profile-icon');

    if (displayElement) {
        if (isVisitante) {
            displayElement.innerText = "Visitante";
        } else {
            const nome = localStorage.getItem('nome_completo');
            displayElement.innerText = nome ? nome.split(' ')[0] : "Usuário";
        }
    }

    if (authButtons) {
        authButtons.style.display = isVisitante ? 'flex' : 'none';
    }

    if (profileIcon && isVisitante) {
        profileIcon.style.color = "#888";
        profileIcon.style.opacity = "0.7";

        profileIcon.onclick = null;
        profileIcon.addEventListener('click', (e) => {
            e.preventDefault();
            showToast("Modo Visitante: Faça login para ver seu perfil.", "error");
        });
    }
}

function verificarAcessoHistorico() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_usuario');

    if (isVisitante || isNaoLogado) {

        showToast(" Acesso Restrito\n\nO Histórico de Consultas está disponível apenas para usuários cadastrados.\nFaça login para salvar e consultar suas avaliações.", 'error');

    } else {

        window.location.href = 'historico.html';
    }
}


document.addEventListener('DOMContentLoaded', () => {
    verificarModoVisitante()
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    if (displayElement) {
        displayElement.innerText = (!isVisitante && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    const initialsElement = document.getElementById('avatarInitials');
    if (initialsElement) {
        if (isVisitante || !nomeCompleto) {

            initialsElement.innerHTML = '<i class="fas fa-user"></i>';

        } else {

            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }

});

function getUserInitials(fullName) {
    if (!fullName) return '--';

    const partes = fullName.trim().split(/\s+/);

    if (partes.length === 0) return '--';

    const primeira = partes[0][0];

    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';

    return (primeira + ultima).toUpperCase();
}

const videoGrid = document.getElementById('videoGrid');

function renderVideos(lista) {
    videoGrid.innerHTML = '';

    if (lista.length === 0) {
        videoGrid.innerHTML = '<p style="color:#888; grid-column:1/-1; text-align:center; padding: 40px 0;">Nenhum vídeo encontrado.</p>';
        return;
    }

    lista.forEach(video => {
        const card = document.createElement('div');
        card.className = 'video-card';

        let playerHTML = '';
        const isYouTube = video.url && (video.url.includes('youtube.com') || video.url.includes('youtu.be'));

        if (isYouTube) {
            playerHTML = `<iframe src="${video.url}" title="${video.titulo}" frameborder="0" allowfullscreen></iframe>`;
        } else {
            const videoSrc = video.url || `../uploads/${video.nome_arquivo}`;
            playerHTML = `
                <video controls style="width:100%; height:100%; border-radius:8px; background:#000;">
                    <source src="${videoSrc}" type="video/mp4">
                    Seu navegador não suporta este vídeo.
                </video>`;
        }

        const dataFormatada = video.data_envio 
            ? new Date(video.data_envio).toLocaleDateString('pt-BR') 
            : new Date().toLocaleDateString('pt-BR');

        card.innerHTML = `
            <div class="video-thumb">
                ${playerHTML}
            </div>
            <div class="video-content">
                <span class="video-cat-badge">${video.categoria || 'Geral'}</span>
                <h3 class="video-title">${video.titulo}</h3>
             <div class="video-footer">
                            <span style="font-size: 0.8rem; color: #888;">
                                <i class="far fa-calendar-alt"></i> ${dataFormatada}
                            </span>
                            
                            <button class="btn-report" 
                                    data-id="${video.id}" 
                                    data-titulo="${video.titulo.replace(/"/g, '&quot;')}" 
                                    title="Denunciar Vídeo">
                                <i class="fas fa-flag"></i>
                            </button>
                        </div>
            </div>
        `;

        videoGrid.appendChild(card);
    });

    adicionarEventosDenuncia();
}

renderVideos(videosData);

btnFilter.addEventListener('click', (e) => {
    e.stopPropagation();
    filterDropdown.classList.toggle('show');
});

window.addEventListener('click', () => {
    if (filterDropdown.classList.contains('show')) {
        filterDropdown.classList.remove('show');
    }
});

let categoriaAtiva = 'todos';

function aplicarFiltros() {
    const termo = searchInput.value.toLowerCase();

    const videosFiltrados = videosData.filter(video => {
        const matchesBusca = video.titulo.toLowerCase().includes(termo);
        const matchesCategoria = (categoriaAtiva === 'todos' || video.categoria === categoriaAtiva);

        return matchesBusca && matchesCategoria;
    });

    renderVideos(videosFiltrados);
    atualizarIndicadorFiltro();
}

function abrirModalDenuncia(id, titulo) {
    videoAtualDenuncia = { id, titulo };
    document.getElementById('tituloVideoDenuncia').textContent = titulo;
    document.querySelectorAll('input[name="motivo"]').forEach(r => r.checked = false);
    const textarea = document.getElementById('motivoDenuncia');
    textarea.value = '';
    textarea.style.display = 'none';
    const modal = document.getElementById('modalDenuncia');
    modal.classList.remove('hidden');
    modal.style.display = 'flex';
}

function adicionarEventosDenuncia() {
    document.querySelectorAll('.btn-report').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.dataset.id;
            const titulo = btn.dataset.titulo;
            if (id && titulo) abrirModalDenuncia(id, titulo);
        });
    });
}

document.getElementById('btnCancelarDenuncia')?.addEventListener('click', () => {
    document.getElementById('modalDenuncia').style.display = 'none';
});

document.querySelectorAll('input[name="motivo"]').forEach(radio => {
    radio.addEventListener('change', () => {
        document.getElementById('motivoDenuncia').style.display = (radio.value === 'Outro') ? 'block' : 'none';
    });
});

document.getElementById('btnEnviarDenuncia')?.addEventListener('click', async () => {
    const motivoSelecionado = document.querySelector('input[name="motivo"]:checked');
    if (!motivoSelecionado) return alert('Selecione um motivo.');

    let motivo = motivoSelecionado.value;
    if (motivo === 'Outro') {
        motivo = document.getElementById('motivoDenuncia').value.trim();
        if (!motivo) return alert('Descreva o motivo.');
    }

    try {
        const response = await fetch('http://localhost:3000/videos/denunciar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ videoId: videoAtualDenuncia.id, tituloVideo: videoAtualDenuncia.titulo, motivo })
        });
        if (response.ok) {
            alert('Denúncia enviada!');
            document.getElementById('modalDenuncia').style.display = 'none';
        }
    } catch (err) {
        showToast('Erro ao conectar ao servidor.', 'error');
    }
});

searchInput.addEventListener('input', aplicarFiltros);

filterOptions.forEach(opt => {
    opt.addEventListener('click', () => {
        categoriaAtiva = opt.getAttribute('data-cat');

        filterOptions.forEach(o => o.classList.remove('active-filter'));
        opt.classList.add('active-filter');

        aplicarFiltros();
    });
});

function atualizarIndicadorFiltro() {
    const btnFilter = document.getElementById('btnFilter');
    if (categoriaAtiva !== 'todos') {
        btnFilter.innerHTML = `<i class="fas fa-filter"></i> Filtrando: <b>${categoriaAtiva}</b>`;
        btnFilter.style.borderColor = "#6fb194";
        btnFilter.style.color = "#6fb194";
        btnFilter.style.background = "#f0f7f4";
    } else {
        btnFilter.innerHTML = `<i class="fas fa-filter"></i> Filtrar`;
        btnFilter.style.borderColor = "#ddd";
        btnFilter.style.color = "#555";
        btnFilter.style.background = "white";
    }
}

document.addEventListener('DOMContentLoaded', async () => {
    const videoGrid = document.querySelector('.video-grid');
    if (!videoGrid) return;

    try {

        const response = await fetch('http://localhost:3000/get-videos');
        const videosSalvos = await response.json();

        if (videosSalvos.length > 0) {
            const categoriasMap = {
                'epi': 'Uso de EPIs',
                'emergencia': 'Protocolos de Emergência',
                'manuseio': 'Manuseio Seguro',
                'armazenamento': 'Armazenamento de Químicos'
            };

            videosSalvos.forEach(video => {
                const catNome = categoriasMap[video.categoria] || 'Geral';

                const dataFormatada = new Date(video.data_envio).toLocaleDateString('pt-BR');

                const card = document.createElement('div');
                card.className = 'video-card';

                card.innerHTML = `
                    <div class="video-thumb" style="display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-play-circle" style="font-size: 3.5rem; color: rgba(255,255,255,0.8); cursor: pointer; transition: transform 0.2s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'"></i>
                        <span style="position: absolute; bottom: 10px; right: 10px; background: #d63031; padding: 3px 8px; border-radius: 4px; font-size: 0.75rem; font-weight: bold;">NOVO</span>
                    </div>
                    
                    <div class="video-content">
                        <span class="video-cat-badge">${catNome}</span>
                        <h3 class="video-title">${video.titulo}</h3>
                        
                        <p style="font-size: 0.85rem; color: #666; margin-bottom: 5px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;">
                            ${video.descricao || 'Sem descrição fornecida.'}
                        </p>
                        
                        <div style="font-size: 0.8rem; color: #0f7143; font-weight: 600; margin-bottom: 15px; display: flex; align-items: center; gap: 5px;">
                            <i class="fab fa-youtube"></i> Criador Original: ${video.criador_original || 'Desconhecido'}
                        </div>
                        
                        <div class="video-footer">
                            <span style="font-size: 0.8rem; color: #888;">
                                <i class="far fa-calendar-alt"></i> ${dataFormatada}
                            </span>
                            <button class="btn-report" title="Opções"><i class="fas fa-ellipsis-v"></i></button>
                        </div>
                    </div>
                `;

                videoGrid.appendChild(card);
                adicionarEventosDenuncia();
            });
        }
    } catch (error) {
        console.error("Erro ao carregar os vídeos do banco:", error);
    }
});