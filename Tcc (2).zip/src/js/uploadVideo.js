function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

function verificarAcessoHistorico() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_usuario');

    if (isVisitante || isNaoLogado) {

        showToast(" Acesso Restrito\n\nO Histórico de Consultas está disponível apenas para usuários cadastrados.\nFaça login para salvar e consultar suas avaliações.", 'error');

    } else {

        window.location.href = 'historico.html';
    }
}

document.addEventListener('DOMContentLoaded', () => {

    const dropZoneElement = document.getElementById("dropZone");
    const inputElement = document.getElementById("videoFile");
    const promptText = dropZoneElement.querySelector(".drop-zone-prompt");

    dropZoneElement.addEventListener("click", () => {
        inputElement.click();
    });

    inputElement.addEventListener("change", (e) => {
        if (inputElement.files.length) {
            updateDropZoneText(inputElement.files[0]);
        }
    });

    dropZoneElement.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropZoneElement.classList.add("dragover");
    });

    ["dragleave", "dragend"].forEach(type => {
        dropZoneElement.addEventListener(type, () => {
            dropZoneElement.classList.remove("dragover");
        });
    });

    dropZoneElement.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZoneElement.classList.remove("dragover");

        if (e.dataTransfer.files.length) {
            inputElement.files = e.dataTransfer.files;
            updateDropZoneText(e.dataTransfer.files[0]);
        }
    });


    function updateDropZoneText(file) {

        if (file.type.startsWith("video/")) {
            promptText.innerHTML = `<span style="color: #0f7143; font-weight: bold;"><i class="fas fa-check-circle"></i> Arquivo selecionado:</span> ${file.name}`;
        } else {
            showToast("Por favor, selecione um arquivo de vídeo válido (MP4, AVI, etc).", 'error');
            inputElement.value = "";
            promptText.innerHTML = `Arraste e solte o arquivo de vídeo aqui ou <strong>clique para procurar</strong>`;
        }
    }
});

function verificarModoVisitante() {

    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    const authButtons = document.querySelector('.auth-buttons');
    const profileIcon = document.querySelector('.profile-icon');

    if (displayElement) {
        if (isVisitante) {
            displayElement.innerText = "Visitante";
        } else {
            const nome = localStorage.getItem('nome_completo');
            displayElement.innerText = nome ? nome.split(' ')[0] : "Usuário";
        }
    }

    if (authButtons) {
        authButtons.style.display = isVisitante ? 'flex' : 'none';
    }

    if (profileIcon && isVisitante) {
        profileIcon.style.color = "#888";
        profileIcon.style.opacity = "0.7";

        profileIcon.onclick = null;
        profileIcon.addEventListener('click', (e) => {
            e.preventDefault();
            showToast("Modo Visitante: Faça login para ver seu perfil.", "error");
        });
    }
}

document.addEventListener('DOMContentLoaded', () => {

    verificarModoVisitante();
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !nomeCompleto;
    const isAnonymous = isVisitante || isNaoLogado;

    const displayElement = document.getElementById('userNameDisplay');
    const initialsElement = document.getElementById('avatarInitials');

    const isAdmin = localStorage.getItem('adm') === 'true';

    if (!isAdmin) {
        document.querySelector('.main-content').style.display = 'none';
        showToast("Acesso Negado: Apenas administradores podem fazer upload de vídeos.", "error");

        setTimeout(() => {
            window.location.href = 'pgVideos.html';
        }, 3000);
        return;
    }

    if (displayElement) {
        displayElement.innerText = (!isAnonymous && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    if (initialsElement) {
        if (isAnonymous) {
            initialsElement.innerHTML = '<i class="fas fa-user"></i>';
        } else {
            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }

    function getUserInitials(fullName) {
        if (!fullName) return '--';
        const partes = fullName.trim().split(/\s+/);
        if (partes.length === 0) return '--';
        const primeira = partes[0][0];
        const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';
        return (primeira + ultima).toUpperCase();
    }


    const toastContainer = document.createElement('div');
    toastContainer.className = 'toast-container';
    document.body.appendChild(toastContainer);

    function showNotification(message, type = 'success') {
        const toast = document.createElement('div');
        toast.className = `custom-toast ${type}`;

        const icon = type === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle';

        toast.innerHTML = `<i class="fas ${icon} fa-lg"></i> <span>${message}</span>`;
        toastContainer.appendChild(toast);

        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }

    const dropZoneElement = document.getElementById("dropZone");
    const inputElement = document.getElementById("videoFile");
    const promptText = dropZoneElement.querySelector(".drop-zone-prompt");

    dropZoneElement.addEventListener("click", () => inputElement.click());

    inputElement.addEventListener("change", (e) => {
        if (inputElement.files.length) updateDropZoneText(inputElement.files[0]);
    });

    dropZoneElement.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropZoneElement.classList.add("dragover");
    });

    ["dragleave", "dragend"].forEach(type => {
        dropZoneElement.addEventListener(type, () => dropZoneElement.classList.remove("dragover"));
    });

    dropZoneElement.addEventListener("drop", (e) => {
        e.preventDefault();
        dropZoneElement.classList.remove("dragover");
        if (e.dataTransfer.files.length) {
            inputElement.files = e.dataTransfer.files;
            updateDropZoneText(e.dataTransfer.files[0]);
        }
    });

    function updateDropZoneText(file) {
        if (file.type.startsWith("video/")) {
            promptText.innerHTML = `<span style="color: #0f7143; font-weight: bold;"><i class="fas fa-check-circle"></i> Arquivo selecionado:</span> ${file.name}`;
        } else {
            showNotification("Por favor, selecione um formato de vídeo válido (MP4, AVI, etc).", "error");
            inputElement.value = "";
            promptText.innerHTML = `Arraste e solte o arquivo de vídeo aqui ou <strong>clique para procurar</strong>`;
        }
    }

    const uploadForm = document.getElementById('uploadForm');

    uploadForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        if (isAnonymous) {
            showNotification("Ação não permitida: Visitantes não podem enviar vídeos. Faça login!", "error");
            return;
        }

        const file = inputElement.files[0];
        if (!file) {
            showNotification("Você esqueceu de anexar o arquivo de vídeo!", "error");
            return;
        }

        const novoVideo = {
            titulo: document.getElementById('videoTitle').value,
            categoria: document.getElementById('videoCategory').value,
            descricao: document.getElementById('videoDesc').value,
            criadorOriginal: document.getElementById('videoCreator').value,
            usuarioUploader: nomeCompleto,
            nomeArquivo: file.name
        };

        try {
            const response = await fetch('http://localhost:3000/upload-video', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(novoVideo)
            });

            if (response.ok) {
                showNotification("Vídeo processado e salvo com sucesso! Redirecionando...", "success");
                setTimeout(() => {
                    window.location.href = 'pgVideos.html';
                }, 2000);
            } else {
                showNotification("Erro ao processar o vídeo no servidor.", "error");
            }
        } catch (error) {
            console.error(error);
            showNotification("Erro de conexão com o servidor.", "error");
        }
    });
});