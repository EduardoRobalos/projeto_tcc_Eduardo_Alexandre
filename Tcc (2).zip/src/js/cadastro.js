
function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

function togglePassword(inputId, iconElement) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        iconElement.classList.remove('fa-eye-slash');
        iconElement.classList.add('fa-eye');
    } else {
        input.type = "password";
        iconElement.classList.remove('fa-eye');
        iconElement.classList.add('fa-eye-slash');
    }
}


document.getElementById('registerForm').addEventListener('submit', async function (e) {
    e.preventDefault();

    const formData = {
        fullname: document.getElementById('fullname').value,
        username: document.getElementById('username').value,
        email: document.getElementById('email').value,
        password: document.getElementById('senhaUsuario').value,
        confirmPassword: document.getElementById('confirm-password').value
    };

    if (formData.password !== formData.confirmPassword) {
        showToast('As senha não coincidem', "error");
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();

        if (response.ok) {
            showToast("Cadastro realizado com sucesso! Redirecionando para o login...", 'sucess');
            window.location.href = '/html/login.html';
        } else {
            alert("Erro: " + result.message);
        }

    } catch (error) {
        console.error("Erro ao conectar com API:", error);
        showToast("Erro ao conectar com o servidor.", 'error');
    }
});

const senhaInput = document.getElementById('senhaUsuario');
const nomeInput = document.getElementById('username');
const msgErro = document.getElementById('msgErroNome');
const emailInput = document.getElementById('email');
const msgErroEmail = document.getElementById('msgErroEmail');
let timeout = null;

function setErro(input, span, temErro) {
    if (temErro) {
        input.classList.add('input-error');
        if (span) span.style.display = 'block';
    } else {
        input.classList.remove('input-error');
        if (span) span.style.display = 'none';
    }
}

nomeInput.addEventListener('input', () => {
    const nomeDigitado = nomeInput.value.trim();

    clearTimeout(timeout);
    removerErro();

    if (nomeDigitado.length === 0) return;

    timeout = setTimeout(async () => {
        try {
            const response = await fetch(`http://localhost:3000/check-username?nome=${nomeDigitado}`);
            const data = await response.json();

            if (data.exists) {
                mostrarErro();
            }
        } catch (error) {
            console.error("Erro ao verificar nome:", error);
        }
    }, 500);
});

if (emailInput) {
    emailInput.addEventListener('input', () => {
        const valor = emailInput.value.trim();
        clearTimeout(timeout);
        setErro(emailInput, msgErroEmail, false); 

        if (valor.length === 0) return;

        timeout = setTimeout(async () => {
            try {
    
                const res = await fetch(`http://localhost:3000/check-email?email=${valor}`);
                const data = await res.json();

                if (data.exists) {
                    setErro(emailInput, msgErroEmail, true);
                }
            } catch (e) { console.error(e); }
        }, 500);
    });
}

if (senhaInput) {
    senhaInput.addEventListener('input', () => {
        const senha = senhaInput.value;

        if (senha.length > 0 && senha.length < 6) {
            setErro(senhaInput, msgErroSenha, true);
        } else {
            setErro(senhaInput, msgErroSenha, false);
        }
    });
}

function mostrarErro() {
    nomeInput.classList.add('input-error'); 
    msgErro.style.display = 'block';       
}

function removerErro() {
    nomeInput.classList.remove('input-error'); 
    msgErro.style.display = 'none';           
}

document.getElementById('registerForm').addEventListener('submit', (e) => {
 
    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            const nomeInvalido = nomeInput && nomeInput.classList.contains('input-error');
            const emailInvalido = emailInput && emailInput.classList.contains('input-error');

            if (nomeInvalido || emailInvalido) {
                e.preventDefault(); 
                showToast("Corrija os campos em vermelho antes de continuar.", 'error');
            }
        });
    }
})

document.getElementById('btnVisitante').addEventListener('click', (e) => {
    e.preventDefault();

    localStorage.removeItem('nome_usuario');
    localStorage.removeItem('nome_completo');

    localStorage.setItem('modo_visitante', 'true');

    window.location.href = 'pgPrincipal.html';
});