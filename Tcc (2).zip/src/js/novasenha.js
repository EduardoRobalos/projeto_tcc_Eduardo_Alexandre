function showToast(message, type = 'success') {
  
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out'); 
        toast.addEventListener('animationend', () => {
            toast.remove(); 
        });
    }, 4000);
}

function toggleVisibility(inputId, iconElement) {
    const input = document.getElementById(inputId);

    if (input.type === "password") {
        input.type = "text";

        iconElement.classList.remove('fa-eye-slash');
        iconElement.classList.add('fa-eye');
    } else {
        input.type = "password";

        iconElement.classList.remove('fa-eye');
        iconElement.classList.add('fa-eye-slash');
    }
}

document.getElementById('resetForm').addEventListener('submit', async (e) => {
    e.preventDefault();

    const urlParams = new URLSearchParams(window.location.search);
    const email = urlParams.get('email');

    const newPassword = document.getElementById('newPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    if (!email) {
        showToast(" Link inválido ou expirado. Tente solicitar a recuperação novamente.", 'error');
        return;
    }

    if (newPassword !== confirmPassword) {
        showToast("As senhas não coincidem!", 'error');
        return;
    }

    if (newPassword.length < 6) {
        showToast("A senha deve ter pelo menos 6 caracteres.", 'error');
        return;
    }

    try {
        const response = await fetch('http://localhost:3000/reset-password', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, newPassword })
        });

        const result = await response.json();

        if (response.ok) {
            showToast(result.message, 'success');

            setTimeout(() => {
                window.location.href = 'login.html';
            }, 2000);
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error(error);
        showToast("Erro ao conectar com o servidor.", 'error');
    }
});