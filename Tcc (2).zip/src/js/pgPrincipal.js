const emailLogado = localStorage.getItem('email');
const searchInput = document.getElementById('searchInput');
const suggestionsBox = document.getElementById('suggestions');
const panel = document.getElementById('avaliacao-panel');

function showToast(message, type = 'success') {
    let container = document.getElementById('toast-container');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toast-container';
        document.body.appendChild(container);
    }

    const isSuccess = type === 'success';
    const iconClass = isSuccess ? 'fa-check-circle' : 'fa-times-circle';
    const title = isSuccess ? 'Sucesso!' : 'Atenção';
    const cssClass = isSuccess ? 'toast-success' : 'toast-error';

    const toast = document.createElement('div');
    toast.className = `eco-toast ${cssClass}`;
    toast.innerHTML = `
        <i class="fas ${iconClass}"></i>
        <div class="toast-content">
            <span class="toast-title">${title}</span>
            <span class="toast-msg">${message}</span>
        </div>
    `;

    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('toast-out');
        toast.addEventListener('animationend', () => toast.remove());
    }, 4000);
}

document.addEventListener('DOMContentLoaded', () => {

    const botoesNav = document.querySelectorAll('.nav-btn');
    const isAdmin = localStorage.getItem('adm') === 'true';

    botoesNav.forEach(botao => {
        if (botao.innerText.trim() === 'Upload' && !isAdmin) {
            botao.style.display = 'none';
        }
    });
    const nomeCompleto = localStorage.getItem('nome_completo');
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';

    const displayElement = document.getElementById('userNameDisplay');
    if (displayElement) {
        displayElement.innerText = (!isVisitante && nomeCompleto) ? nomeCompleto : 'Visitante';
    }

    const initialsElement = document.getElementById('avatarInitials');
    if (initialsElement) {
        if (isVisitante || !nomeCompleto) {

            initialsElement.innerHTML = '<i class="fas fa-user"></i>';

        } else {

            initialsElement.innerText = getUserInitials(nomeCompleto);
        }
    }


});

function verificarAcessoHistorico() {
  
    const isVisitante = localStorage.getItem('modo_visitante') === 'true';
    const isNaoLogado = !localStorage.getItem('email') && !localStorage.getItem('nome_usuario');

    if (isVisitante || isNaoLogado) {

        showToast(" Acesso Restrito\n\nO Histórico de Consultas está disponível apenas para usuários cadastrados.\nFaça login para salvar e consultar suas avaliações.", 'error');

    } else {

        window.location.href = 'historico.html';
    }
}

const urlParams = new URLSearchParams(window.location.search);

const profileIcon = document.querySelector('.profile-icon');
profileIcon.onclick = () => {
    const logado = localStorage.getItem('email');
    if (logado) {

        if (a) {
            window.location.href = 'perfil.html';
        } else {
            localStorage.removeItem('email');
            location.reload();
        }
    } else {
        window.location.href = 'login.html';
    }
};

const isUrlAnon = urlParams.get('mode') === 'anonymous';
const isLocalAnon = localStorage.getItem('modo_visitante') === 'true';

if (isUrlAnon) {
    localStorage.setItem('modo_visitante', 'true');
    localStorage.removeItem('nome_usuario');
    localStorage.removeItem('nome_completo');
    localStorage.removeItem('email');
}

const isAnonymous = isUrlAnon || isLocalAnon;

const authButtons = document.querySelector('.auth-buttons');
const displayElement = document.getElementById('userNameDisplay');

document.addEventListener('DOMContentLoaded', () => {

    if (displayElement) {
        if (isAnonymous) {
            displayElement.innerText = 'Visitante';
        } else {
            const nomeCompleto = localStorage.getItem('nome_completo');
            displayElement.innerText = nomeCompleto || 'Usuário';
        }
    }

    if (authButtons) {
        authButtons.style.display = isAnonymous ? 'flex' : 'none';
    }

    if (profileIcon) {
        if (isAnonymous) {
            profileIcon.style.color = "#888";
            profileIcon.style.opacity = "0.7";
            profileIcon.onclick = () => {
                showToast("Modo Visitante: Faça login para ver seu perfil.", "error");
            };
        } else {
            profileIcon.style.opacity = "1";
            profileIcon.onclick = () => {
                window.location.href = 'perfil.html';
            };
        }
    }
});

function exibirResiduoNaTela(item) {
    gerarEpisPorRisco(item);
    suggestionsBox.style.display = 'none';
    searchInput.value = item.nome;
    panel.style.display = 'block';

    document.getElementById('resClass').innerText = item.classe;

    const tagsDiv = document.getElementById('tagsFeatures');
    tagsDiv.innerHTML = '';
    if (item.toxico) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Tóxico</div>`;
    if (item.corrosivo) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Corrosivo</div>`;
    if (item.inflamavel) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Inflamável</div>`;

    document.getElementById('resScoreNum').innerText = item.risco_score;
    document.getElementById('resRiskText').innerText = item.risco_nivel;

    const riskBar = document.getElementById('resRiskBar');
    if (item.risco_score >= 8) {
        riskBar.style.backgroundColor = "#d63031"; 
    } else if (item.risco_score >= 5) {
        riskBar.style.backgroundColor = "#f39c12"; 
    } else {
        riskBar.style.backgroundColor = "#2ecc71"; 
    }

    setTimeout(() => {
        riskBar.style.width = (item.risco_score * 10) + '%';
    }, 100);

    const incompDiv = document.getElementById('incompList');
    incompDiv.innerHTML = '';
    if (item.incompativeis) {
        const lista = item.incompativeis.split(',');
        lista.forEach(subst => {
            incompDiv.innerHTML += `<div class="incomp-item"><i class="fas fa-times-circle"></i> ${subst}</div>`;
        });
    }

    const goodDiv = document.getElementById('storageGood');
    const badDiv = document.getElementById('storageBad');
    goodDiv.innerHTML = '<small style="color:#aaa; display:block; margin-bottom:10px;">Recomendado</small>';
    badDiv.innerHTML = '<small style="color:#aaa; display:block; margin-bottom:10px;">Não Fazer</small>';

    if (item.armazenamento_bom) {
        item.armazenamento_bom.split(',').forEach(dica => {
            goodDiv.innerHTML += `<div style="margin-bottom:8px;"><i class="fas fa-check-circle"></i> ${dica}</div>`;
        });
    }
    if (item.armazenamento_ruim) {
        item.armazenamento_ruim.split(',').forEach(dica => {
            badDiv.innerHTML += `<div style="margin-bottom:8px;"><i class="fas fa-times-circle"></i> ${dica}</div>`;
        });
    }
}

let residuoAtual = null;

function toggleSimulacao() {
    const panel = document.getElementById('simulation-options');
    const arrow = document.getElementById('sim-arrow');

    if (panel.style.display === 'block') {
        panel.style.display = 'none';
        arrow.className = 'fas fa-chevron-down';

        document.querySelector('.simulation-banner').style.borderRadius = '12px';
    } else {
        panel.style.display = 'block';
        arrow.className = 'fas fa-chevron-up';

        document.querySelector('.simulation-banner').style.borderRadius = '12px 12px 0 0';
    }
}

function mostrarCenario(tipo) {

    const item = residuoAtual || { nome: "Genérico", toxico: true };
    const nomeChave = item.nome.toLowerCase().trim(); 

    const resultBox = document.getElementById('sim-result-box');
    const title = document.getElementById('sim-result-title');
    const textDiv = document.getElementById('sim-result-text');

    let htmlContent = '<ul class="step-list">';
    let passos = [];

    if (cenariosEspecificos[nomeChave] && cenariosEspecificos[nomeChave][tipo]) {
        passos = cenariosEspecificos[nomeChave][tipo];

        title.innerHTML += ' <span style="font-size:0.7rem; background:#d63031; color:white; padding:2px 6px; border-radius:4px; vertical-align:middle;">Protocolo Específico</span>';
    }

    else {
        passos = gerarPassosGenericos(item, tipo);
    }

    if (tipo === 'vazamento') title.innerHTML = '<i class="fas fa-fill-drip"></i> Vazamento / Derramamento';
    if (tipo === 'pele') title.innerHTML = '<i class="fas fa-user-injured"></i> Contato Humano';
    if (tipo === 'fogo') title.innerHTML = '<i class="fas fa-fire-extinguisher"></i> Incêndio / Explosão';

    passos.forEach(passo => {
        htmlContent += `<li>${passo}</li>`;
    });
    htmlContent += '</ul>';

    textDiv.innerHTML = htmlContent;
    resultBox.style.display = 'block';

    resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function gerarPassosGenericos(item, tipo) {
    let lista = [];

    if (tipo === 'vazamento') {
        if (item.inflamavel) lista.push("Elimine fontes de ignição imediatamente.");
        if (item.corrosivo) lista.push("Não toque no material. Use diques de contenção.");
        if (item.toxico) lista.push("Evacue a área e use máscara respiratória.");
        lista.push("Absorva com material inerte (areia/vermiculita).");
    }
    else if (tipo === 'pele') {
        if (item.corrosivo) lista.push("Lave com água corrente por 20 minutos. Não neutralize.");
        else lista.push("Lave com água e sabão neutro.");
        lista.push("Remova roupas contaminadas.");
        lista.push("Consulte a FISPQ e busque ajuda médica.");
    }
    else if (tipo === 'fogo') {
        if (item.inflamavel) {
            lista.push("Use extintor PQS ou CO2.");
            lista.push("Risco de explosão de vapores.");
        } else {
            lista.push("Material não inflamável, mas pode liberar gases tóxicos.");
        }
        lista.push("Afaste-se contra o vento.");
    }
    return lista;
}

searchInput.addEventListener('input', async () => {
    const text = searchInput.value;

    if (text.length < 2) {
        suggestionsBox.style.display = 'none';
        return;
    }

    const res = await fetch(`http://localhost:3000/search-residuo?term=${text}`);
    const data = await res.json();

    suggestionsBox.innerHTML = ''; 

    if (data.length > 0) {
        suggestionsBox.style.display = 'block';
        data.forEach(item => {
            const div = document.createElement('div');
            div.className = 'suggestion-item';
            div.innerText = item.nome;
            div.onclick = () => carregarResiduo(item);
            suggestionsBox.appendChild(div);
        });
    } else {
        suggestionsBox.style.display = 'none';
    }
});

document.addEventListener('DOMContentLoaded', () => {
    const ultimoSalvo = localStorage.getItem('ultimo_residuo_visualizado');

    if (ultimoSalvo) {
        const item = JSON.parse(ultimoSalvo);
        exibirResiduoNaTela(item);
    }
});

function carregarResiduo(item) {
    gerarEpisPorRisco(item);
    suggestionsBox.style.display = 'none';
    searchInput.value = item.nome;
    panel.style.display = 'block';

    document.getElementById('resClass').innerText = item.classe;

    const tagsDiv = document.getElementById('tagsFeatures');
    tagsDiv.innerHTML = '';
    if (item.toxico) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Tóxico</div>`;
    if (item.corrosivo) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Corrosivo</div>`;
    if (item.inflamavel) tagsDiv.innerHTML += `<div><i class="fas fa-circle" style="font-size:0.5rem"></i> Inflamável</div>`;

    document.getElementById('resScoreNum').innerText = item.risco_score;
    document.getElementById('resRiskText').innerText = item.risco_nivel;

    setTimeout(() => {
        document.getElementById('resRiskBar').style.width = (item.risco_score * 10) + '%';
    }, 100);

    const incompDiv = document.getElementById('incompList');
    incompDiv.innerHTML = '';
    if (item.incompativeis) {
        const lista = item.incompativeis.split(',');
        lista.forEach(subst => {
            incompDiv.innerHTML += `<div class="incomp-item"><i class="fas fa-times-circle"></i> ${subst}</div>`;
        });
    }

    const goodDiv = document.getElementById('storageGood');
    const badDiv = document.getElementById('storageBad');
    goodDiv.innerHTML = '<small style="color:#aaa; display:block; margin-bottom:10px;">Recomendado</small>';
    badDiv.innerHTML = '<small style="color:#aaa; display:block; margin-bottom:10px;">Não Fazer</small>';

    if (item.armazenamento_bom) {
        item.armazenamento_bom.split(',').forEach(dica => {
            goodDiv.innerHTML += `<div style="margin-bottom:8px;"><i class="fas fa-check-circle"></i> ${dica}</div>`;
        });
    }
    if (item.armazenamento_ruim) {
        item.armazenamento_ruim.split(',').forEach(dica => {
            badDiv.innerHTML += `<div style="margin-bottom:8px;"><i class="fas fa-times-circle"></i> ${dica}</div>`;
        });
    }

    let tagsParaSalvar = [];
    if (item.toxico) tagsParaSalvar.push("Tóxico");
    if (item.corrosivo) tagsParaSalvar.push("Corrosivo");
    if (item.inflamavel) tagsParaSalvar.push("Inflamável");

    const novaConsulta = {
        residuo_nome: item.nome,
        classe: item.classe,
        risco_score: item.risco_score,
        tags: tagsParaSalvar,
        data: new Date().toLocaleDateString()
    };

    let historicoAtual = JSON.parse(localStorage.getItem('meu_historico_consultas')) || [];

    historicoAtual.unshift(novaConsulta);

    localStorage.setItem('meu_historico_consultas', JSON.stringify(historicoAtual));

    if (!isAnonymous) {
        salvarNoHistorico(item);
    }
    localStorage.setItem('ultimo_residuo_visualizado', JSON.stringify(item));
}

function salvarNoHistorico(item) {
    let historico = JSON.parse(localStorage.getItem('meu_historico_consultas')) || [];

    historico = historico.filter(log => log.residuo_nome !== item.nome);

    const novoLog = {
        residuo_nome: item.nome,
        classe: item.classe,
        risco_score: item.risco_score,
        tags: [
            item.toxico ? "Tóxico" : null,
            item.corrosivo ? "Corrosivo" : null,
            item.inflamavel ? "Inflamável" : null
        ].filter(t => t !== null), 
  
        dados_completos: item
    };

    historico.unshift(novoLog);

    localStorage.setItem('meu_historico_consultas', JSON.stringify(historico));
}

function trocarTela(tela) {
    const contentArea = document.getElementById('content-area');

    document.querySelectorAll('.nav-item').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');

    if (tela === 'home') {
        contentArea.innerHTML = `
            <div class="search-section">
                <input type="text" placeholder="Pesquisar resíduo..." class="search-bar">
                </div>
        `;
    }

    else if (tela === 'historico') {
        contentArea.innerHTML = `
            <div class="history-banner">
                <div>
                    <h1>Histórico de Consulta</h1>
                    <p id="count">Carregando...</p>
                </div>
                <button class="btn-limpar" onclick="limparTudo()"><i class="fas fa-trash"></i> Limpar</button>
            </div>
            <div id="lista-historico"></div>
        `;
        carregarDadosHistorico();
    }
}

async function carregarDadosHistorico() {
    const email = localStorage.getItem('userEmail');
    const response = await fetch(`http://localhost:3000/get-history?email=${email}`);
    const logs = await response.json();

    document.getElementById('count').innerText = `${logs.length} Consultas realizadas`;
    const lista = document.getElementById('lista-historico');

    logs.forEach(log => {
        lista.innerHTML += `
            <div class="history-card ${log.risco_score >= 8 ? 'high-risk' : ''}">
                <div style="display:flex; align-items:center; gap:15px;">
                    <div style="background:#d63031; color:white; width:40px; height:40px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold;">
                        ${log.risco_score}
                    </div>
                    <div>
                        <h3 style="margin:0;">${log.residuo_nome}</h3>
                        <small>${log.classe || 'Classe I'}</small>
                    </div>
                </div>
                <div style="text-align:right;">
                    <span style="font-size:0.8rem; color:#888;">Risco</span>
                    <strong style="font-size:1.8rem; color:#d63031;">${log.risco_score}/10</strong>
                </div>
            </div>
        `;
    });
}

window.onload = () => trocarTela('pgPrincipal.html');

document.addEventListener('DOMContentLoaded', () => {

    const nomeCompleto = localStorage.getItem('nome_completo');
    const displayElement = document.getElementById('userNameDisplay');

    if (nomeCompleto && displayElement) {
        displayElement.innerText = nomeCompleto;
    }
});

function getUserInitials(fullName) {
    if (!fullName) return '--';

    const partes = fullName.trim().split(/\s+/); 

    if (partes.length === 0) return '--';

    const primeira = partes[0][0]; 

    const ultima = partes.length > 1 ? partes[partes.length - 1][0] : '';

    return (primeira + ultima).toUpperCase();
}

function gerarEpisPorRisco(item) {

    const todosEpis = {
        luvaNitrilica: { nome: "Luvas Nitrílicas", img: "/img/Luvas Nitrílicas.webp", desc: "Protege contra contato com produtos químicos corrosivos." },
        luvaRaspa: { nome: "Luvas de Raspa", img: "/img/Luvas de Raspa.png", desc: "Proteção mecânica para manuseio de caixas e tambores." }, 
        mascara: { nome: "Máscara Respiratória", img: "/img/Máscara respiratória.png", desc: "Filtra gases, vapores ácidos e partículas nocivas." },
        oculos: { nome: "Óculos de Segurança", img: "/img/Óculos de Segurança.png", desc: "Protege os olhos contra respingos e vapores." },
        faceShield: { nome: "Protetor Facial", img: "/img/Protetor Facial.png", desc: "Proteção total do rosto contra projeção de líquidos." }, 
        bota: { nome: "Calçado de Segurança", img: "/img/botas epi.png", desc: "Impermeável, protege os pés contra impactos e químicos." },
        avental: { nome: "Avental Protetor", img: "/img/Colete de Alta Visibilidade.webp", desc: "Protege o corpo contra derramamentos e respingos." }
    };

    let episRecomendados = [];

    episRecomendados.push(todosEpis.bota);
    episRecomendados.push(todosEpis.oculos);

    if (item.toxico) {
        episRecomendados.push(todosEpis.mascara);
        episRecomendados.push(todosEpis.luvaNitrilica);
    }

    if (item.corrosivo) {
        episRecomendados.push(todosEpis.luvaNitrilica);
        episRecomendados.push(todosEpis.avental);

    }

    if (item.inflamavel) {
        episRecomendados.push(todosEpis.avental);

    }

    let episUnicos = [...new Set(episRecomendados)];

    const container = document.getElementById('epiListDynamic');
    const panel = document.getElementById('epi-panel');

    if (episUnicos.length > 0) {
        panel.style.display = 'block';
        container.innerHTML = ''; 

        episUnicos.forEach(epi => {
            container.innerHTML += `
                <div class="epi-card-item">
                    <div class="epi-img-box">
                        <img src="${epi.img}" alt="${epi.nome}" onerror="this.src='https://via.placeholder.com/150?text=EPI'">
                    </div>
                    <div>
                        <h4>${epi.nome}</h4>
                        <p>${epi.desc}</p>
                    </div>
                    <div class="epi-status">
                        <span class="epi-dot"></span> Obrigatório
                    </div>
                </div>
            `;
        });
    } else {
        panel.style.display = 'none';
    }
}

function toggleChat() {
    const chat = document.getElementById('chatWindow');
    chat.style.display = chat.style.display === 'flex' ? 'none' : 'flex';
}

function handleChatKey(event) {
    if (event.key === 'Enter') enviarMensagemIA();
}

async function enviarMensagemIA() {
    const input = document.getElementById('chatInput');
    const mensagem = input.value.trim();
    if (!mensagem) return;

    const chatMessages = document.getElementById('chatMessages');

    chatMessages.innerHTML += `<div class="msg user-msg">${mensagem}</div>`;
    input.value = '';
    chatMessages.scrollTop = chatMessages.scrollHeight;

    const digitandoId = 'typing-' + Date.now();
    chatMessages.innerHTML += `<div class="msg ai-msg" id="${digitandoId}"><i class="fas fa-circle-notch fa-spin"></i> A pensar...</div>`;
    chatMessages.scrollTop = chatMessages.scrollHeight;

    try {
        const response = await fetch('http://localhost:3000/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: mensagem })
        });

        const data = await response.json();

        const indicador = document.getElementById(digitandoId);
        if (indicador) indicador.remove();

        if (response.ok) {
            let respostaFormatada = data.reply.replace(/\n/g, '<br>');
            respostaFormatada = respostaFormatada.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
            chatMessages.innerHTML += `<div class="msg ai-msg">${respostaFormatada}</div>`;
        }

        else {
            chatMessages.innerHTML += `<div class="msg ai-msg" style="color: #d63031;">Erro no Servidor: ${data.error || 'Falha ao contatar a IA.'}</div>`;
        }

    } catch (error) {

        const indicador = document.getElementById(digitandoId);
        if (indicador) indicador.remove();
        chatMessages.innerHTML += `<div class="msg ai-msg" style="color: #d63031;">Desculpe, não consegui conectar ao servidor.</div>`;
    }

    chatMessages.scrollTop = chatMessages.scrollHeight;
}

const cenariosEspecificos = {

    "hipoclorito de sódio": {
        vazamento: [
            "<strong>PERIGO:</strong> Não misture com ácidos ou amônia (libera gás cloro mortal).",
            "Contenha o vazamento com diques de areia.",
            "Não utilize serragem (risco de combustão se secar).",
            "Dilua com bastante água se o vazamento for pequeno e em área ventilada."
        ],
        pele: [
            "Causa queimaduras químicas e irritação severa.",
            "Lave com água corrente por 15 a 20 minutos.",
            "A sensação de 'pele ensaboada' indica que o produto ainda está agindo: continue lavando.",
            "Retire roupas contaminadas."
        ],
        fogo: [
            "Não é inflamável, mas o calor libera gás Cloro (tóxico).",
            "Resfrie os recipientes expostos ao fogo com neblina de água.",
            "Utilize máscara autônoma."
        ]
    },

    "hidróxido de sódio": {
        vazamento: [
            "<strong>CORROSIVO FORTE:</strong> Reage exotermicamente (gera calor) com água.",
            "Isole a área. O contato com alumínio ou zinco libera Hidrogênio (explosivo).",
            "Recolha o sólido com pá de plástico limpa.",
            "Neutralize resíduos com solução diluída de ácido acético (vinagre)."
        ],
        pele: [
            "<strong>AÇÃO LENTA:</strong> A dor pode demorar, mas o dano é profundo.",
            "Se sentir a pele escorregadia, o produto ainda está corroendo.",
            "Lave com água em abundância até sumir a sensação de sabão.",
            "Não tente neutralizar na pele com vinagre (o calor da reação piora a lesão)."
        ],
        fogo: [
            "Não é combustível.",
            "Use o extintor apropriado para o fogo ao redor.",
            "Cuidado com a água de combate ao fogo se tornando corrosiva (pH alto)."
        ]
    },

    "permanganato de potássio": {
        vazamento: [
            "<strong>OXIDANTE FORTE:</strong> Afaste de materiais combustíveis (papel, óleo, madeira).",
            "Não use serragem para absorver (risco de fogo espontâneo).",
            "Recolha com ferramentas que não gerem faíscas.",
            "Mancha superfícies e pele de marrom/roxo permanentemente."
        ],
        pele: [
            "Causa manchas marrons e queimaduras.",
            "Lave com água e sabão imediatamente.",
            "As manchas na pele saem com o tempo, mas a queimadura precisa de cuidado médico."
        ],
        fogo: [
            "Acelera violentamente a queima de outros materiais.",
            "Pode explodir se em contato com substâncias orgânicas ou ácidos.",
            "Use grandes quantidades de água para inundar a área."
        ]
    },

    "sódio metálico": {
        vazamento: [
            "<strong>PERIGO MORTAL:</strong> Reage violentamente com a umidade do ar e água.",
            "Cubra imediatamente com óleo mineral ou querosene se exposto.",
            "Não toque com as mãos nuas (a umidade da pele causa reação).",
            "Mantenha longe de qualquer fonte de água."
        ],
        pele: [
            "<strong>NÃO LAVE COM ÁGUA IMEDIATAMENTE</strong> se houver fragmentos sólidos.",
            "Remova os pedaços sólidos com pinça ou óleo vegetal.",
            "Só após remover o metal, lave com água em abundância para tratar a queimadura alcalina."
        ],
        fogo: [
            "<strong>CLASSE D:</strong> NUNCA USE ÁGUA, CO2 OU ESPUMA.",
            "Use apenas areia seca, grafite em pó ou extintor de Cloreto de Sódio (Lith-X).",
            "A água causará explosão de Hidrogênio."
        ]
    },

    "acetato de chumbo": {
        vazamento: [
            "<strong>TÓXICO E CUMULATIVO:</strong> Evite gerar poeira.",
            "Não deixe entrar em ralos ou esgoto (contaminação grave da água).",
            "Use aspirador com filtro HEPA ou pano úmido para recolher.",
            "Isole a área."
        ],
        pele: [
            "Pode ser absorvido pela pele.",
            "Lave vigorosamente com água e sabão.",
            "Troque de roupa imediatamente para não levar o pó para casa."
        ],
        fogo: [
            "Emite vapores tóxicos de chumbo.",
            "Use máscara autônoma completa.",
            "Apague com pó químico ou CO2."
        ]
    },

    "fenol sólido": {
        vazamento: [
            "Absorção rápida pela pele e inalação.",
            "Se aquecido, libera vapores inflamáveis e tóxicos.",
            "Recolha com cuidado para não gerar pó.",
            "Use máscara respiratória com filtro para vapores orgânicos."
        ],
        pele: [
            "<strong>PERIGO:</strong> Possui efeito anestésico (você não sente a queimadura na hora).",
            "A pele fica branca e insensível.",
            "Lave preferencialmente com Polietilenoglicol (PEG 300 ou 400).",
            "Se não tiver PEG, lave com água corrente por 30 minutos."
        ],
        fogo: [
            "Combustível. Libera vapores tóxicos.",
            "Risco de explosão do vapor em ambientes fechados.",
            "Use espuma resistente a álcool ou neblina de água."
        ]
    },

    "ácido bórico": {
        vazamento: [
            "Baixa toxicidade aguda, mas perigoso se ingerido ou inalado.",
            "Varra ou aspire evitando levantar poeira.",
            "Pode ser descartado como resíduo químico comum, seguindo normas locais."
        ],
        pele: [
            "Pode causar irritação em peles sensíveis ou feridas.",
            "Lave com água e sabão.",
            "Se houver contato com os olhos, enxágue bem."
        ],
        fogo: [
            "Não é inflamável.",
            "O produto libera água quando aquecido acima de 100°C.",
            "Use agente extintor adequado ao fogo circundante."
        ]
    },

    "sulfato de cobre": {
        vazamento: [
            "<strong>POLUENTE MARINHO:</strong> Extremamente tóxico para peixes e algas.",
            "Impeça a entrada em bueiros, rios ou drenos.",
            "Recolha o pó azul com pá e vassoura.",
            "Guarde em recipiente seco e fechado."
        ],
        pele: [
            "Irritante. Causa coceira e eczema.",
            "Lave com bastante água e sabão.",
            "Não leve as mãos à boca (tóxico por ingestão)."
        ],
        fogo: [
            "Não inflamável.",
            "Se aquecido, decompõe-se liberando óxidos de enxofre (gases ácidos).",
            "Use proteção respiratória."
        ]
    },

    "nitrato de prata": {
        vazamento: [
            "<strong>MANCHA TUDO:</strong> Causa manchas pretas difíceis de remover em pisos e pele.",
            "Oxidante: mantenha longe de materiais combustíveis.",
            "Recolha com papel absorvente (que deve ser tratado como resíduo perigoso).",
            "Neutralize com solução de sal de cozinha (precipita Cloreto de Prata)."
        ],
        pele: [
            "Deixa a pele preta (Argiria localizada) que demora semanas para sair.",
            "É corrosivo e causa queimaduras.",
            "Lave imediatamente com solução salina (água e sal) e depois água corrente."
        ],
        fogo: [
            "Oxidante forte: aumenta a intensidade do fogo.",
            "Pode liberar vapores de óxidos de nitrogênio (tóxicos).",
            "Use neblina de água em abundância."
        ]
    },

    "carbeto de cálcio": {
        vazamento: [
            "<strong>PERIGO DE EXPLOSÃO:</strong> O contato com água ou umidade do ar libera Acetileno.",
            "O gás Acetileno é extremamente inflamável e explosivo.",
            "Mantenha a área seca e ventilada. Não use água na limpeza.",
            "Use ferramentas antifaiscantes de bronze/latão."
        ],
        pele: [
            "O pó reage com o suor formando cal hidratada (queimadura alcalina e térmica).",
            "Limpe o pó a seco antes de lavar.",
            "Lave com água em abundância após remover o sólido."
        ],
        fogo: [
            "<strong>NUNCA USE ÁGUA.</strong>",
            "Use pó químico seco, areia ou CO2.",
            "Se o fogo for grande, evacue a área (risco de explosão)."
        ]
    },

    "dicromato de potássio": {
        vazamento: [
            "<strong>CANCERÍGENO E OXIDANTE:</strong> Evite qualquer contato com o pó.",
            "Tóxico para o ambiente aquático.",
            "Umedeça levemente para não levantar poeira ao varrer.",
            "Separe de materiais inflamáveis (papel, solventes)."
        ],
        pele: [
            "Causa úlceras profundas ('furos de cromo') e alergias severas.",
            "Pode ser absorvido pela pele.",
            "Lave com água em abundância e sabão.",
            "Busque auxílio médico se houver ferida."
        ],
        fogo: [
            "Forte oxidante. Pode causar ignição de combustíveis.",
            "Libera vapores tóxicos de Cromo.",
            "Use neblina de água para resfriar, mas contenha a água (tóxica)."
        ]
    }
};